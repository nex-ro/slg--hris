import DashboardLayouts from "@/Layouts/DasboardLayout";

function Dashboard() {

  return (
   <DashboardLayouts>
    <div className="">
        <p>user</p>
    </div>

   </DashboardLayouts>

  );
}

export default Dashboard;

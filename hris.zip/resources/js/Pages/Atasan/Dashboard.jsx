import DashboardLayouts from "@/Layouts/DasboardLayout";

function Dashboard() {

  return (
   <DashboardLayouts>
        <p>user</p>
   </DashboardLayouts>

  );
}

export default Dashboard;

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Katering</title>
    <style>
        @page {
            margin: 50px 50px;
        }
        
        body {
            font-family: Arial, sans-serif;
            font-size: 10px;
            margin: 0;
            padding: 0;
        }
        
        .title {
            text-align: center;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        .container {
            width: 100%;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .main-table {
            margin-bottom: 0;
        }
        
        .main-table th {
            background-color: #CCCCCC;
            font-weight: bold;
            padding: 5px;
            border: 1px solid #000;
            text-align: center;
        }
        
        .main-table td {
            border: 1px solid #000;
            padding: 3px 5px;
        }
        
        .tower-header {
            background-color: #CCCCCC;
            font-weight: bold;
            text-align: center;
        }
        
        .no-col {
            width: 8%;
            text-align: center;
        }
        
        .nama-col {
            width: 42%;
            text-align: left;
        }
        
        /* Keterangan Table */
        .keterangan-table {
            width: 100%;
            margin-top: 0;
        }
        
        .keterangan-table td {
            padding: 3px 5px;
            border: 1px solid #000;
        }
        
        .keterangan-table td.no-border {
            border: none;
        }
        
        .highlight {
            background-color: #FFFF00;
            font-weight: bold;
        }
        
        .center {
            text-align: center;
        }
        
        .left {
            text-align: left;
        }
        
        .border-top {
            border-top: 2px solid #000 !important;
        }
        
        .border-bottom {
            border-bottom: 2px solid #000 !important;
        }
        
        /* Layout 2 kolom */
        .two-column {
            width: 100%;
        }
        
        .left-column {
            width: 58%;
            float: left;
        }
        
        .right-column {
            width: 40%;
            float: right;
            margin-left: 2%;
        }
        
        .clearfix::after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>
<body>
    <div class="title">Laporan Absen <?php echo e($tanggal); ?></div>
    
    <div class="container clearfix">
        <!-- Left Column: Data Hadir -->
        <div class="left-column">
            <table class="main-table">
                <thead>
                    <tr>
                        <th colspan="2" class="tower-header">Eifel</th>
                        <th colspan="2" class="tower-header">Liberty</th>
                    </tr>
                    <tr>
                        <th class="no-col">No</th>
                        <th class="nama-col">Nama</th>
                        <th class="no-col">No</th>
                        <th class="nama-col">Nama</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $maxRows = max(45, $eifelHadir->count(), $libertyHadir->count());
                        $eifelArray = $eifelHadir->values()->all();
                        $libertyArray = $libertyHadir->values()->all();
                    ?>
                    
                    <?php for($i = 0; $i < $maxRows; $i++): ?>
                        <tr>
                            <td class="no-col"><?php echo e($i + 1); ?></td>
                            <td class="nama-col">
                                <?php echo e(isset($eifelArray[$i]) ? ($eifelArray[$i]['user']['name'] ?? $eifelArray[$i]['nama'] ?? $eifelArray[$i]['name'] ?? '') : ''); ?>

                            </td>
                            <td class="no-col"><?php echo e($i + 1); ?></td>
                            <td class="nama-col">
                                <?php echo e(isset($libertyArray[$i]) ? ($libertyArray[$i]['user']['name'] ?? $libertyArray[$i]['nama'] ?? $libertyArray[$i]['name'] ?? '') : ''); ?>

                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Right Column: Keterangan -->
        <div class="right-column">
            <table class="keterangan-table">
                <!-- Keterangan Eifel -->
                <tr>
                    <td colspan="3" class="highlight">Keterangan :</td>
                </tr>
                <tr>
                    <td colspan="3" class="highlight center">tower Eifel</td>
                </tr>
                <tr class="border-bottom">
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                <tr>
                    <td>TOTAL</td>
                    <td class="center"><?php echo e($eifelTotal); ?></td>
                    <td>Orang</td>
                </tr>
                <tr>
                    <td>Sakit</td>
                    <td class="center"><?php echo e($eifelSakit->count()); ?></td>
                    <td>
                        <?php $__currentLoopData = $eifelSakit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?>

                            <?php if(!$loop->last): ?>, <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <?php if($eifelSakit->count() > 1): ?>
                    <?php $__currentLoopData = $eifelSakit->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>Cuti</td>
                    <td class="center"><?php echo e($eifelCuti->count()); ?></td>
                    <td>
                        <?php if($eifelCuti->count() > 0): ?>
                            <?php echo e($eifelCuti->first()['user']['name'] ?? $eifelCuti->first()['nama'] ?? $eifelCuti->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($eifelCuti->count() > 1): ?>
                    <?php $__currentLoopData = $eifelCuti->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>Dinas Luar</td>
                    <td class="center"><?php echo e($eifelDinasLuar->count()); ?></td>
                    <td>
                        <?php if($eifelDinasLuar->count() > 0): ?>
                            <?php echo e($eifelDinasLuar->first()['user']['name'] ?? $eifelDinasLuar->first()['nama'] ?? $eifelDinasLuar->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($eifelDinasLuar->count() > 1): ?>
                    <?php $__currentLoopData = $eifelDinasLuar->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>Keluar kantor</td>
                    <td class="center"><?php echo e($eifelKeluar->count()); ?></td>
                    <td>
                        <?php if($eifelKeluar->count() > 0): ?>
                            <?php echo e($eifelKeluar->first()['user']['name'] ?? $eifelKeluar->first()['nama'] ?? $eifelKeluar->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($eifelKeluar->count() > 1): ?>
                    <?php $__currentLoopData = $eifelKeluar->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>WFH</td>
                    <td class="center"><?php echo e($eifelWFH->count()); ?></td>
                    <td>
                        <?php if($eifelWFH->count() > 0): ?>
                            <?php echo e($eifelWFH->first()['user']['name'] ?? $eifelWFH->first()['nama'] ?? $eifelWFH->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($eifelWFH->count() > 1): ?>
                    <?php $__currentLoopData = $eifelWFH->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr class="border-top">
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" class="highlight"><strong>Total: <?php echo e($eifelHadirTotal); ?></strong></td>
                </tr>
                
                <!-- Spacing -->
                <tr>
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                
                <!-- Keterangan Liberty -->
                <tr>
                    <td colspan="3" class="highlight">Keterangan :</td>
                </tr>
                <tr>
                    <td colspan="3" class="highlight center">tower liberty</td>
                </tr>
                <tr class="border-bottom">
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                <tr>
                    <td>TOTAL</td>
                    <td class="center"><?php echo e($libertyTotal); ?></td>
                    <td>Orang</td>
                </tr>
                <tr>
                    <td>Sakit</td>
                    <td class="center"><?php echo e($libertySakit->count()); ?></td>
                    <td>
                        <?php if($libertySakit->count() > 0): ?>
                            <?php echo e($libertySakit->first()['user']['name'] ?? $libertySakit->first()['nama'] ?? $libertySakit->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($libertySakit->count() > 1): ?>
                    <?php $__currentLoopData = $libertySakit->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>Cuti</td>
                    <td class="center"><?php echo e($libertyCuti->count()); ?></td>
                    <td>
                        <?php if($libertyCuti->count() > 0): ?>
                            <?php echo e($libertyCuti->first()['user']['name'] ?? $libertyCuti->first()['nama'] ?? $libertyCuti->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($libertyCuti->count() > 1): ?>
                    <?php $__currentLoopData = $libertyCuti->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>Dinas Luar</td>
                    <td class="center"><?php echo e($libertyDinasLuar->count()); ?></td>
                    <td>
                        <?php if($libertyDinasLuar->count() > 0): ?>
                            <?php echo e($libertyDinasLuar->first()['user']['name'] ?? $libertyDinasLuar->first()['nama'] ?? $libertyDinasLuar->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($libertyDinasLuar->count() > 1): ?>
                    <?php $__currentLoopData = $libertyDinasLuar->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr>
                    <td>Keluar kantor</td>
                    <td class="center"><?php echo e($libertyKeluar->count()); ?></td>
                    <td>
                        <?php if($libertyKeluar->count() > 0): ?>
                            <?php echo e($libertyKeluar->first()['user']['name'] ?? $libertyKeluar->first()['nama'] ?? $libertyKeluar->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($libertyKeluar->count() > 1): ?>
                    <?php $__currentLoopData = $libertyKeluar->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
                <tr>
                    <td>WFH</td>
                    <td class="center"><?php echo e($libertyWFH->count()); ?></td>
                    <td>
                        <?php if($libertyWFH->count() > 0): ?>
                            <?php echo e($libertyWFH->first()['user']['name'] ?? $libertyWFH->first()['nama'] ?? $libertyWFH->first()['name'] ?? ''); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php if($libertyWFH->count() > 1): ?>
                    <?php $__currentLoopData = $libertyWFH->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo e($item['user']['name'] ?? $item['nama'] ?? $item['name'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <tr class="border-top">
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" class="highlight"><strong>Total: <?php echo e($libertyHadirTotal); ?></strong></td>
                </tr>
                
                <!-- Spacing -->
                <tr>
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3" class="no-border">&nbsp;</td>
                </tr>
                
                <!-- Akumulasi -->
                <tr>
                    <td colspan="3" class="highlight">Akumulasi</td>
                </tr>
                <tr>
                    <td colspan="2">Lantai 19</td>
                    <td class="center"><?php echo e($totalLantai19); ?></td>
                </tr>
                <tr>
                    <td colspan="2">Lantai 1</td>
                    <td class="center"><?php echo e($totalLantai1); ?></td>
                </tr>
                <tr>
                    <td colspan="2">Marein</td>
                    <td class="center"><?php echo e($totalMarein); ?></td>
                </tr>
                <tr>
                    <td colspan="2" class="highlight"><strong>Total</strong></td>
                    <td class="center highlight"><strong><?php echo e($totalAkumulasi); ?></strong></td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html><?php /**PATH D:\internship\project\hris\resources\views/pdf/katering-report.blade.php ENDPATH**/ ?>